//IDs for objects//
public enum ID
{
    Player(),
    BasicEnemy(),
    FastEnemy(),
    SmartEnemy(),
    Boss1(),
    MenuParticle(),
    Trail()
}
